<?php
session_start();
include("functions.php");
chkssid();

$pdo = db_con();

$stmt = $pdo->prepare("SELECT * FROM user_table");
$status = $stmt->execute();
$view="";
if($status == false){
queryError($stmt);
}else{
while($r = $stmt->fetch(PDO::FETCH_ASSOC)){
$view .= '<div>';
$view .= '<table>';
$view .= '<tr>';
$view .= '<td class="td1">';
$view .= "[".h($r["id"])."]";
$view .= h($r["name"]);
$view .= '</td>';
$view .= '<td class="td2">';
$view .= h($r["email"]);
$view .= '</td>';
$view .= '<td class="td3">';
$view .= h($r["lid"]);
$view .= '</td>';
$view .= '<td class="td4">';
$view .= h($r["lpw"]);
$view .= '</td>';
$view .= '<td class="td5">';
$view .= h($r["indate"]);
$view .= '</td>';
$view .= '<td class="td6">';
$view .= '<a href="henshu_user.php?id='.$r["id"].'">';
$view .= '[編集]';
$view .= '</a>'; 
$view .= '</td>';
$view .= '<td class="td7">';
$view .= '</a>'; 
$view .= '<a href="delete3.php?id='.$r["id"].'">';
$view .= '[削除]';
$view .= '</a>';
$view .= '</td>';

// ."-".h($r["name"])."-".h($r["email"])."-".h($r["lid"])."-".h($r["lpw"])."-".h($r["indate"]);
// $view .= '</td>';
// $view .= '<a href="henshu3.php?id='.$r["id"].'">';
// $view .= '[編集]';
// $view .= '</a>'; 
// $view .= '<a href="delete3.php?id='.$r["id"].'">';
// $view .= '[削除]';
// $view .= '</a>';
// $view .= '</table>';
// $view .= '</div>';
}
}
?>


<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ブックマーク</title>
<!-- <link rel="stylesheet" href="css/range.css">
<link href="css/bootstrap.min.css" rel="stylesheet"> -->
<style>
div{
padding: 10px;font-size:16px;
}
.td1{
width: 150px;
}
.td2{
width: 300px;
}
.td3{
width: 150px;
}
.td4{
width: 150px;
}
.td5{
width: 200px;
}
.td6{
width: 50px;
}
.td7{
width: 50px;
}
a{
text-decoration: none;
color: #000;
}
a:hover{
text-decoration: underline;
}
</style>
</head>
<body id="main">
<!-- Head[Start] -->
<header>
<nav class="navbar navbar-default">
<div class="container-fluid">
<div class="navbar-header">
<a class="navbar-brand" href="index3.php">戻る</a>
<a class="navbar-brand" href="index3.php">ログアウト</a>
</div>
</nav>
</header>
<!-- Head[End] -->

<!-- Main[Start] -->
<div>
<div class="container jumbotron"><?=$view?></div>
</div>
</div>
<!-- Main[End] -->

</body>
</html>