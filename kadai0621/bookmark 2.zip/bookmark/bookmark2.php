<?php
session_start();

include("functions.php");
chkssid();

$pdo = db_con();

$stmt = $pdo->prepare("SELECT * FROM book_table ORDER BY id DESC");
$status = $stmt->execute();

$view="";
if($status==false){
querryError($stmt);
}else{
while($r = $stmt->fetch(PDO::FETCH_ASSOC)){
$view .= '<div class=bookmark_box>';
$view .= '<a href="'.$r["url"].'?id='.$r["id"].'" target=”_blank” class="bookmark">';
$view .= $r["title"]."-".$r["memo"]."-".$r["tag"];
$view .= '<span><img src="images/img8.jpg">';
$view .= '</a>'; 
$view .= '<a href="henshu3.php?id='.$r["id"].'">';
$view .= '[編集]';
$view .= '</a>'; 
$view .= '<a href="delete3.php?id='.$r["id"].'">';
$view .= '[削除]';
$view .= '</a>';
$view .= '<p class="date">';
$view .= $r["indate"];
$view .= '</p>';
$view .= '</div>';
}
}
?>

<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ブックマーク</title>
<!-- <link rel="stylesheet" href="css/range.css">
<link href="css/bootstrap.min.css" rel="stylesheet"> -->
<style>
/* div{
padding: 10px;font-size:16px;
} */
.navbar{
height: 50px;
line-height: 50px;
}
.navbar-brand{
padding-left: 30px;
}
.bookmark{
font-size: 20px;
}
.bookmark:hover{
position: relative;
}
.bookmark span{
display: none;
position: absolute;
top: 50px;
left: 500px;
}
.bookmark:hover span{
border: none;
display: block;
}
img{
width: 800px;
height: auto;
}
.date{
font-size: 14px;
font-weight: normal;
}
a{
text-decoration: none;
/* color: #000; */
color: #5190fc;
}
a:hover{
text-decoration: underline;
}
#sar{
width: 550px;
height: 30px; 
font-size: 16px;
}
#sbtn{
width: 60px;
height: 36px;
background-color: #5190fc;
color: #fff;
}
.kensaku{
width: 1080px;
margin: 0 auto;
}
.head{
display: flex;
}
.container{
padding: 24px;
}
.title{
margin-left: 10px;
}
</style>
</head>
<body id="main">
<!-- Head[Start] -->
<header>
<nav class="navbar navbar-default">
<div class="head">
<a class="navbar-brand" href="index3.php">ログアウト</a>
<div class="kensaku">
<input type="text" id="sar" placeholder=" ブックマークを検索する">
<button id="sbtn">検索</button>
</div>
</div>
</nav>
</header>
<!-- Head[End] -->

<!-- Main[Start] -->
<div>
<h2>ブックマーク</h2>
<a href="bookamark_add.php" stylr="color:5190fc" class="title">ブックマークを追加</a>
<div class="container jumbotron" id="view"><?=$view?></div>
</div>
</div>
<!-- Main[End] -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
<script>
document.querySelector("#sbtn").onclick = function(){
$.ajax({
type: "post",
url: "bookmark2.php",
data:{
sar: $("#sar").val(),
},
dataType: "html",
success: function(data){
if(data=="false"){
alert("エラー");
}else{
$("#view").html(data);
}
}
});
}

</script>


</body>
</html>


