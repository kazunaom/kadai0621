<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <title>ブックマーク</title>
  <!-- <link href="css/bootstrap.min.css" rel="stylesheet"> -->
  <style>
/* .container-fluid{
    height: 60px;
    line-height: 60px;

} */
.navbar{
      /* position: fixed;
      background-color: #fff; 
      clear: both;*/
      border-bottom: solid 1px;
}
.navbar-header{
    text-decoration: none;
    font-size: 20px;
    color: #000;
}
ul{
    display: flex;
    list-style: none;
    justify-content: right;
}
li{
    margin-right: 20px;
    width: 150px;
    text-align: center;
}
a{
    text-decoration: none;
    color: #000;
}
a:hover{
    text-decoration: underline;
}
.hide{
    display: none;
}
h1{
    color: #fff;
    text-align: center;
    padding: 48px;
    text-shadow: 2px  2px 5px #000,
                -2px  2px 5px #000,
                 2px -2px 5px #000,
                -2px -2px 5px #000;
}
.img{
    width: 1000px;
    height: 400px;
    background-image: url(images/img2.jpg);
    margin: 0 auto;
    background-repeat: no-repeat;
    border: solid 1px #ded7d7;
}
  </style>
  <!-- <style>
  /* div{
      padding: 10px;font-size:16px;
  } */
  body{
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      width: 100vw;
      height: 100vh;
  }
  a{
      text-decoration: none;
      color: #000;
  }
  a:hover{
      text-decoration: underline;
  }
  .head{
      width: 1280px;
      margin: 0 auto;
      /* position: relative; */
  }
  .container-fluid{
      height: 60px;
      line-height: 60px;
      float: left;
  }
.navbar{
      /* position: fixed;
      background-color: #fff; 
      clear: both;*/
      border-bottom: solid 1px;
}
.navbar-header{
      text-decoration: none;
      font-size: 20px;
      color: #000;
  }
  ul{
      display: flex;
      list-style: none;
      float: right;
  }
  li{
      margin-right: 20px;
      width: 100px;
      text-align: center;
  }
  /* .head_img{
      background-image:url(wework-mexico-coworking-space.jpg);
      background-repeat: no-repeat;
      width: 100%;
      height: 100px;
      padding: 50px 0;
      color: #fff;
      font-size: 60px;
      text-align: center;
      line-height: 100px;
      font-weight: bold;
      clear: both;
  } */
.head_text_box{
    height: 100vh;
    background-color: rgb(245,245,245,0.7);
    background-image: url(https://getpocket.com/i/v4/signup_graphic@1x.jpg);
    background-repeat: no-repeat;
    background-position: 200px 150px;
    line-height: 1.75;
    /* text-align: center; */
    padding: 60px 0;
    box-sizing: border-box;
    clear: both;
}

.jumbotron{
    width: 1080px;
    margin: 0 auto;
    padding: 50px 0;
}
/* .name_kanji{
    width: 463px;
    height: 51px;
}
.name_hiragana{
    width: 463px;
    height: 51px;
}
.tel{
    width: 463px;
    height: 51px;
}
.mail{
    width: 463px;
    height: 51px;
}
.mail_again{
    width: 463px;
    height: 51px;
} */
input{
    font-size: 22px;
    width: 248px;
    height: 44.38px;
    margin: 0 auto;
}
.send{
    background-color: #000;
    width: 300px;
    height: 70px;
    color: #fff;
    border-radius: 5px;
}
.send:hover{
    opacity: 0.5;
    cursor: pointer;
}
.inp1{
    float: left;
    font-weight: bold;
    margin: 24px 0;
}
.inp1_text{
    font-size: 14px;
    font-weight: normal;
}
.inp2{
    float: right;
    font-weight: bold;
    margin: 24px 0;
}
.inp2_text{
    font-size: 14px;
    font-weight: normal;
}
.inp3{
    clear: both;
    float: left;
    font-weight: bold;
    margin: 24px 0;
}
.inp3_text{
    font-size: 14px;
    font-weight: normal;
}
.inp4{
    clear:both;
    float: left;
    font-weight: bold;
    margin: 24px 0;
}
.inp4_text{
    font-size: 14px;
    font-weight: normal;
}
.inp5{
    /* clear:both; */
    float: right;
    font-weight: bold;
    margin: 24px 0;
}
.inp5_text{
    font-size: 14px;
    font-weight: normal;
}
.inp6{
    clear:both;
    float: left;
    font-weight: bold;
    margin: 24px 0;
}
.inp6_text{
    font-size: 14px;
    font-weight: normal;
}
.inp7{
    /* clear:both; */
    float: right;
    font-weight: bold;
    margin: 24px 0;
}
.inp7_text{
    font-size: 14px;
    font-weight: normal;
}
.inp8{
    clear:both;
    float: left;
    font-weight: bold;
    margin: 24px 0;
}
.inp8_text{
    font-size: 14px;
    font-weight: normal;
}
.send{
    clear:both;
    float: left;
    font-weight: bold;
    margin: 24px 0;
}
form{
    width: 354px;
    height: 507.484px;
    background-color: #fff;
    position: fixed;
    top: 100px;
    right: 250px;
    padding: 10px 0;
    border: solid 1px #c2bcbc;
    border-radius: 5px;
}
fieldset{
    border: none;
}
legend{
    text-align: center;
    font-size: 24px;
    font-weight: bold;
}
.login_text{
    width: 248px;
    height: 44.38px;
    text-decoration: none;
    color: #fff;
    font-size: 18px;
}
.login_btn{
    background-color: #FF1493;
}
/* .inp8_text{
    font-size: 14px;
    font-weight: normal;
} */
  </style> -->
  <script src="js/jquery-2.1.3.min.js"></script>
<script src="js/jquery.quicksearch.js"></script>
</head>
<body>
    <header>
        <nav class="navbar navbar-default">
            <div class="head">
                <ul>
                    <li><a href="user.php">ユーザー登録</a></li>
                    <li><a href="login_form.php">ユーザーログイン</a></li>
                    <li><a href="kanri_lg.php">管理者ログイン</a></li>
                    <!-- <li class="hide"><a href="select3.php">Data</a></li> -->
                </ul>
            </div>
        </nav>
    </header>

<div>
    <h2>ブックマーク</h2>
   
    <div class="container jumbotron" id="view"><?=$view?></div>
  </div>
</div>


</body>
</html>
